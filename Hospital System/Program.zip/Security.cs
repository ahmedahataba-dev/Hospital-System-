﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Hospital_System
{
	//made by Youssef Essam
	internal class Security : Employee
	{
		int badgeNumber;
		String? shift; //morning, evening, night
		private string? name;

		public static List<Security> securities = new List<Security>();
		public new string? Name
		{
			get => name;
			set
			{
				if (string.IsNullOrWhiteSpace(value))
				{
					throw new ArgumentException("Name cannot be empty.");
				}
				name = value;
			}
		}

		public string? Shift
		{
			get { return shift; }
			set
			{
				if (string.IsNullOrWhiteSpace(value))
				{
					throw new ArgumentException("Shift cannot be empty.");
				}
				shift = value;
			}
		}
		public int BadgeNumber
		{
			get { return badgeNumber; }
			set
			{
				if (value <= 0)
				{
					throw new ArgumentException("Badge number must be a positive integer.");
				}
				badgeNumber = value;
			}
		}

		public Security(string name, string badgeNumber, string shift, int age, GenderType gender, string Nationalid, string phoneNumber, string email, string address, decimal salary, double experienceyears) 
		: base(name, age, gender, Nationalid, phoneNumber, email, address, salary, experienceyears)
		{
			this.Name = name;
			this.BadgeNumber = int.Parse(badgeNumber.Replace("SEC-", ""));
			this.Shift = shift;
		}
		//public Security(string name, string autoBadgeString, string shiftTime) : base(name)
		//{
		//	this.Name = name;
		//	this.BadgeNumber = int.Parse(autoBadgeString.Replace("SEC-", ""));
		//	this.Shift = shiftTime;
		//}																

	}
}