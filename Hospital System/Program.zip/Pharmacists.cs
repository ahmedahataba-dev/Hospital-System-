﻿namespace Hospital_System
{
	internal class PharmacyStaff : Employee
	{
		public static List<PharmacyStaff> pharmacists = new List<PharmacyStaff>();
		public static int pharmacyStaffIdCounter = 1;

		public int PharmacyStaffId { get; private set; }
		public string Role { get; set; }

		public PharmacyStaff(string name, int age, GenderType gender, string nationalId, string phoneNumber, string email, string address, decimal salary, int experienceYears, string role)
			: base(name, age, gender, nationalId, phoneNumber, email, address, salary, experienceYears)
		{
			// ID Assignment logic
			this.PharmacyStaffId = pharmacyStaffIdCounter++;
			this.Role = role;
			HospitalData.AddPharmacists(this);
		}
	}
}